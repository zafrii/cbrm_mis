<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-03 05:45:38 --> 404 Page Not Found: Assets/dist
ERROR - 2019-12-03 05:46:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-03 05:46:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-03 05:46:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-03 05:46:32 --> 404 Page Not Found: Public/plugins
