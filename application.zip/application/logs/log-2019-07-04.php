<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-04 07:40:06 --> 404 Page Not Found: admin/Pages/UI
ERROR - 2019-07-04 07:42:06 --> 404 Page Not Found: admin/Pages/UI
ERROR - 2019-07-04 07:44:26 --> 404 Page Not Found: Ui/buttons
ERROR - 2019-07-04 08:03:32 --> 404 Page Not Found: admin/Ui/pages
ERROR - 2019-07-04 08:03:41 --> 404 Page Not Found: Ui/sliders
ERROR - 2019-07-04 08:04:08 --> 404 Page Not Found: Ui/sliders
ERROR - 2019-07-04 08:04:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-04 08:04:20 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-04 08:04:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-04 08:04:21 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-04 08:07:46 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-04 08:07:46 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-04 08:07:47 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-04 08:07:47 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-04 08:10:21 --> 404 Page Not Found: admin/Ui/pages
ERROR - 2019-07-04 08:37:23 --> 404 Page Not Found: admin/Forms/pages
ERROR - 2019-07-04 10:42:03 --> 404 Page Not Found: admin/Forms/pages
