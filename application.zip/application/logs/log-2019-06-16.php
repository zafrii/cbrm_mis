<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-16 07:44:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ci_role_permissions' C:\wamp64\www\ci_role_permissions\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-06-16 07:44:09 --> Unable to connect to the database
ERROR - 2019-06-16 07:46:08 --> 404 Page Not Found: Admin/Dashboard
ERROR - 2019-06-16 07:46:12 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-06-16 07:46:34 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-06-16 07:46:37 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-06-16 07:46:43 --> 404 Page Not Found: Admin/auth
ERROR - 2019-06-16 07:46:58 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-06-16 07:47:02 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-06-16 07:47:30 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-06-16 07:47:40 --> 404 Page Not Found: Admin/welcome
ERROR - 2019-06-16 07:48:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Dashboard_model C:\wamp64\www\ci_role_permissions\system\core\Loader.php 348
ERROR - 2019-06-16 07:56:16 --> 404 Page Not Found: Plugins/morris
ERROR - 2019-06-16 07:56:16 --> 404 Page Not Found: Dist/img
ERROR - 2019-06-16 07:56:16 --> 404 Page Not Found: Dist/img
ERROR - 2019-06-16 07:56:17 --> 404 Page Not Found: Dist/img
ERROR - 2019-06-16 07:56:17 --> 404 Page Not Found: Dist/img
ERROR - 2019-06-16 07:56:17 --> 404 Page Not Found: Dist/img
ERROR - 2019-06-16 07:56:17 --> 404 Page Not Found: Dist/img
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:57:09 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:59:46 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 07:59:46 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:59:46 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 07:59:47 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:17 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 08:00:17 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:17 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:18 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:22 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 08:00:22 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:22 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:22 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 162
ERROR - 2019-06-16 08:00:38 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 08:00:38 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:38 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:39 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:39 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:39 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:39 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:39 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:39 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:00:52 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 08:01:24 --> 404 Page Not Found: admin/Plugins/morris
ERROR - 2019-06-16 08:01:24 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:24 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:25 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:25 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:25 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:25 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:25 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:01:25 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:04 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:04 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:05 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:05 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:05 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:05 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:05 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:02:05 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:00 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:00 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:00 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:00 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:00 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:00 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:07 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:07 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:07 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:07 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:07 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:07 --> 404 Page Not Found: admin/Dist/img
ERROR - 2019-06-16 08:03:57 --> 404 Page Not Found: admin/Indexhtml/index
ERROR - 2019-06-16 10:01:27 --> Severity: Notice --> Undefined variable: navbar C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 39
ERROR - 2019-06-16 10:01:27 --> Severity: Notice --> Undefined variable: sidebar C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 168
ERROR - 2019-06-16 10:01:27 --> Severity: Notice --> Undefined variable: footer C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_footer.php 1
ERROR - 2019-06-16 10:01:42 --> Severity: Notice --> Undefined variable: navbar C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 39
ERROR - 2019-06-16 10:01:42 --> Severity: Notice --> Undefined variable: sidebar C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 168
ERROR - 2019-06-16 10:01:42 --> Severity: Notice --> Undefined variable: footer C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_footer.php 1
ERROR - 2019-06-16 10:02:23 --> Severity: Notice --> Undefined variable: navbar C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 39
ERROR - 2019-06-16 10:02:23 --> Severity: Notice --> Undefined variable: footer C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_footer.php 1
ERROR - 2019-06-16 10:02:29 --> Severity: Notice --> Undefined variable: navbar C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_header.php 39
ERROR - 2019-06-16 10:02:29 --> Severity: Notice --> Undefined variable: footer C:\wamp64\www\ci_role_permissions\application\views\admin\includes\_footer.php 1
