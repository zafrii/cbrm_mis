<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-14 21:25:22 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\ci_role_permissions\application\views\admin\dashboard\index.php 31
ERROR - 2019-07-14 21:25:22 --> Severity: Notice --> Undefined variable: active_users C:\wamp64\www\ci_role_permissions\application\views\admin\dashboard\index.php 46
ERROR - 2019-07-14 21:25:22 --> Severity: Notice --> Undefined variable: deactive_users C:\wamp64\www\ci_role_permissions\application\views\admin\dashboard\index.php 61
ERROR - 2019-07-14 21:26:10 --> Severity: error --> Exception: Call to undefined function auth_check() C:\wamp64\www\ci_role_permissions\application\controllers\admin\Dashboard.php 7
ERROR - 2019-07-14 21:26:13 --> Severity: error --> Exception: Call to undefined function auth_check() C:\wamp64\www\ci_role_permissions\application\controllers\admin\Dashboard.php 7
ERROR - 2019-07-14 21:26:16 --> Severity: error --> Exception: Call to undefined function auth_check() C:\wamp64\www\ci_role_permissions\application\controllers\admin\Dashboard.php 7
ERROR - 2019-07-14 22:30:16 --> Severity: Warning --> file_get_contents(http://localhost/ci_role_permissions/public/dist/css/mpdfstyletables.css): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\wamp64\www\ci_role_permissions\application\controllers\admin\Invoices.php 208
ERROR - 2019-07-14 22:30:17 --> Severity: Warning --> fopen(C:\wamp64\www\ci_role_permissions\/uploads/invoices/10021.pdf): failed to open stream: No such file or directory C:\wamp64\www\ci_role_permissions\application\helpers\mpdf\mpdf.php 7744
