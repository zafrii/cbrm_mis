<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-17 07:44:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\wamp64\www\ci_role_permissions\system\core\Loader.php 348
ERROR - 2019-06-17 07:56:31 --> 404 Page Not Found: admin/Index2html/index
ERROR - 2019-06-17 07:58:57 --> 404 Page Not Found: Auth/register
ERROR - 2019-06-17 07:59:28 --> 404 Page Not Found: Auth/register
ERROR - 2019-06-17 07:59:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-06-17 07:59:34 --> 404 Page Not Found: Public/dist
ERROR - 2019-06-17 07:59:34 --> 404 Page Not Found: Public/dist
ERROR - 2019-06-17 07:59:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-06-17 07:59:34 --> 404 Page Not Found: Public/dist
ERROR - 2019-06-17 07:59:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-06-17 07:59:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-06-17 07:59:35 --> 404 Page Not Found: Public/dist
ERROR - 2019-06-17 07:59:35 --> 404 Page Not Found: Public/dist
ERROR - 2019-06-17 07:59:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-06-17 07:59:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-06-17 07:59:35 --> 404 Page Not Found: Public/dist
ERROR - 2019-06-17 08:06:21 --> 404 Page Not Found: Auth/register
ERROR - 2019-06-17 08:06:44 --> 404 Page Not Found: Index2html/index
ERROR - 2019-06-17 08:11:53 --> 404 Page Not Found: Index2html/index
ERROR - 2019-06-17 08:12:13 --> 404 Page Not Found: Index2html/index
ERROR - 2019-06-17 08:15:37 --> 404 Page Not Found: admin/Admin/dashboard
ERROR - 2019-06-17 08:15:43 --> 404 Page Not Found: admin/Admin/dashboard
ERROR - 2019-06-17 08:16:26 --> 404 Page Not Found: Auth/login
