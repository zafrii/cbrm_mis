<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-26 05:46:28 --> 404 Page Not Found: Assets/dist
ERROR - 2019-08-26 05:51:33 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 05:51:33 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 05:51:33 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 05:51:33 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:22:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:22:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:22:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:22:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:23:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:23:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:23:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-08-26 06:23:45 --> 404 Page Not Found: Public/plugins
