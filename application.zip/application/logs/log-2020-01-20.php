<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-20 10:49:18 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:17:18 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:17:25 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:17:50 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:17:52 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:17:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:18:02 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:23:21 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:23:38 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:29:22 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:29:40 --> Severity: error --> Exception: syntax error, unexpected ')' F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Dashboard.php 32
ERROR - 2020-01-20 11:29:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:30:47 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:31:39 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 00:32:42 --> Could not find the language line "Blank"
ERROR - 2020-01-20 00:32:42 --> Could not find the language line "Blank"
ERROR - 2020-01-20 00:32:54 --> Could not find the language line "Blank"
ERROR - 2020-01-20 11:37:59 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 11:38:06 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:38:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:38:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 11:40:54 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 12:05:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 12:05:53 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 12:09:22 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 12:09:27 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-20 12:09:39 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 15:35:00 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 15:35:10 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-20 15:35:29 --> 404 Page Not Found: Assets/dist
