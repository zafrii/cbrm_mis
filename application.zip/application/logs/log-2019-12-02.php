<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-02 06:33:46 --> 404 Page Not Found: Assets/dist
ERROR - 2019-12-02 06:34:22 --> 404 Page Not Found: Assets/dist
ERROR - 2019-12-02 06:34:35 --> 404 Page Not Found: Assets/dist
ERROR - 2019-12-02 06:35:23 --> 404 Page Not Found: Assets/dist
ERROR - 2019-12-02 07:15:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 07:15:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 07:15:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 07:15:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 19:46:35 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\adminlite_2020\application\helpers\mpdf\mpdf.php 32511
