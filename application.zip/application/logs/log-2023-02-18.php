<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-18 10:56:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\admin_lite\adminlite\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-02-18 10:56:07 --> Unable to connect to the database
ERROR - 2023-02-18 11:03:14 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 11:08:35 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 13:50:37 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 13:56:30 --> 404 Page Not Found: Dist/img
ERROR - 2023-02-18 13:56:50 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2023-02-18 14:00:02 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:09:32 --> 404 Page Not Found: Public/plugins
ERROR - 2023-02-18 14:09:32 --> 404 Page Not Found: Public/plugins
ERROR - 2023-02-18 14:17:27 --> Severity: error --> Exception: Too few arguments to function Home::site_lang(), 0 passed in C:\xampp\htdocs\mis\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\mis\application\controllers\Home.php 11
ERROR - 2023-02-18 14:19:05 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\mis\application\controllers\Home.php 14
ERROR - 2023-02-18 14:19:05 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\mis\application\controllers\Home.php 23
ERROR - 2023-02-18 14:24:02 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:44:36 --> 404 Page Not Found: Auth/login
ERROR - 2023-02-18 14:45:25 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:48:45 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:50:12 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:53:03 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:54:24 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 15:01:16 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 15:04:23 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 15:04:31 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 15:05:33 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 15:11:08 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 04:15:34 --> Could not find the language line "mobileno"
ERROR - 2023-02-18 15:15:34 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 15:49:08 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 04:50:23 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:567 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 04:55:47 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:567 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 04:57:37 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:13:53 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:13:53 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com
:587 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:14:17 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:14:17 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com
:587 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:16:19 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:16:19 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com
:587 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:17:49 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:17:49 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com
:587 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 05:18:56 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 16:28:05 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 16:51:37 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 16:57:33 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 16:58:22 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 16:58:31 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 16:58:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 18:22:10 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 18:45:30 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 07:45:33 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 07:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 07:47:27 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 07:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 07:47:31 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 07:47:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 19:03:21 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 08:03:25 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 08:03:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 08:04:04 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 08:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 19:07:15 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 19:07:24 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 19:19:04 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 19:19:29 --> 404 Page Not Found: User3/auth
ERROR - 2023-02-18 19:29:42 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 19:35:10 --> 404 Page Not Found: Agreement/index
ERROR - 2023-02-18 08:35:30 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 08:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 08:35:41 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 08:35:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 19:38:57 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 20:15:24 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 20:15:35 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 20:16:09 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 09:16:20 --> Severity: Notice --> Undefined variable: admin_roles C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 09:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mis\application\views\user\agreement\index.php 27
ERROR - 2023-02-18 20:18:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 21:37:08 --> 404 Page Not Found: Public/plugins
ERROR - 2023-02-18 21:37:08 --> 404 Page Not Found: Public/plugins
ERROR - 2023-02-18 21:37:20 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 21:37:24 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 21:40:44 --> 404 Page Not Found: Public/plugins
ERROR - 2023-02-18 21:40:44 --> 404 Page Not Found: Public/plugins
ERROR - 2023-02-18 21:40:45 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 21:48:12 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 10:54:37 --> Could not find the language line "services"
ERROR - 2023-02-18 10:54:46 --> Could not find the language line "services"
ERROR - 2023-02-18 10:54:49 --> Could not find the language line "services"
ERROR - 2023-02-18 11:04:46 --> Could not find the language line "services"
ERROR - 2023-02-18 22:04:49 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 11:04:53 --> Could not find the language line "services"
ERROR - 2023-02-18 11:05:01 --> Could not find the language line "services"
ERROR - 2023-02-18 11:06:33 --> Could not find the language line "services"
ERROR - 2023-02-18 11:13:08 --> Could not find the language line "services"
ERROR - 2023-02-18 11:13:13 --> Could not find the language line "services"
ERROR - 2023-02-18 11:14:39 --> Could not find the language line "services"
ERROR - 2023-02-18 11:14:41 --> Could not find the language line "services"
ERROR - 2023-02-18 22:14:44 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 11:14:47 --> Could not find the language line "services"
ERROR - 2023-02-18 11:14:51 --> Could not find the language line "services"
ERROR - 2023-02-18 11:18:59 --> Could not find the language line "services"
ERROR - 2023-02-18 11:18:59 --> Could not find the language line "services_list"
ERROR - 2023-02-18 11:18:59 --> Could not find the language line "add new service"
ERROR - 2023-02-18 22:19:02 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 11:19:07 --> Could not find the language line "services"
ERROR - 2023-02-18 11:19:07 --> Could not find the language line "services_list"
ERROR - 2023-02-18 11:19:07 --> Could not find the language line "add new service"
ERROR - 2023-02-18 11:21:25 --> Could not find the language line "services_list"
ERROR - 2023-02-18 11:21:25 --> Could not find the language line "add new service"
ERROR - 2023-02-18 11:22:12 --> Could not find the language line "add new service"
ERROR - 2023-02-18 11:49:30 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 23:04:07 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 23:04:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2023-02-18 23:05:54 --> 404 Page Not Found: Assets/dist
ERROR - 2023-02-18 14:28:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\mis\application\helpers\mpdf\mpdf.php 32511
ERROR - 2023-02-18 14:34:30 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
ERROR - 2023-02-18 15:50:43 --> Severity: error --> Exception: Call to undefined method Invoice_model::get_services_list() C:\xampp\htdocs\mis\application\controllers\user\Orders.php 90
ERROR - 2023-02-18 16:55:15 --> Severity: Warning --> fsockopen(): unable to connect to smtp-relay.sendinblue.com:587 (A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
) C:\xampp\htdocs\mis\system\libraries\Email.php 2069
