<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-02 05:34:44 --> 404 Page Not Found: Access_denied/index
ERROR - 2019-07-02 05:34:48 --> 404 Page Not Found: Access_denied/index
ERROR - 2019-07-02 05:35:51 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:37:22 --> 404 Page Not Found: admin/Add/index
ERROR - 2019-07-02 05:38:39 --> 404 Page Not Found: admin/Admin/list_data
ERROR - 2019-07-02 05:38:39 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:38:54 --> 404 Page Not Found: admin/Admin/filterdata
ERROR - 2019-07-02 05:38:54 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:39:39 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:40:00 --> 404 Page Not Found: admin/Add/index
ERROR - 2019-07-02 05:44:23 --> 404 Page Not Found: admin/Admin/index
ERROR - 2019-07-02 05:44:49 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:45:13 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:46:10 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:46:15 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:46:30 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:46:48 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:48:52 --> 404 Page Not Found: admin/Users/index
ERROR - 2019-07-02 05:48:54 --> 404 Page Not Found: admin/Users/add
ERROR - 2019-07-02 05:49:03 --> 404 Page Not Found: admin/Users/list_data
ERROR - 2019-07-02 05:49:03 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:49:17 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:49:27 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:50:55 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:51:00 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 05:51:08 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 06:02:40 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 06:33:12 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 06:33:23 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 06:59:43 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 06:59:52 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 07:00:03 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 07:00:11 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 07:00:15 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 07:00:31 --> 404 Page Not Found: admin/Pages/widgets.html
ERROR - 2019-07-02 07:52:43 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 07:52:52 --> 404 Page Not Found: admin/Users/index
ERROR - 2019-07-02 07:52:59 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 07:54:26 --> 404 Page Not Found: admin/Users/index
ERROR - 2019-07-02 09:36:51 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\ci_role_permissions\application\controllers\admin\Users.php 16
ERROR - 2019-07-02 09:36:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:36:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:39:06 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\ci_role_permissions\application\controllers\admin\Users.php 16
ERROR - 2019-07-02 09:39:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:39:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:39:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:39:08 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:41:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:41:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:41:15 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:41:15 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:50:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:50:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:50:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:50:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:50:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 09:50:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 10:06:34 --> 404 Page Not Found: admin/Pages/forms
ERROR - 2019-07-02 10:56:45 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 10:56:49 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\ci_role_permissions\application\controllers\admin\Users.php 93
ERROR - 2019-07-02 10:56:59 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\ci_role_permissions\application\controllers\admin\Admin_roles.php 52
ERROR - 2019-07-02 10:57:08 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\ci_role_permissions\application\controllers\admin\Users.php 93
ERROR - 2019-07-02 10:59:03 --> Severity: error --> Exception: syntax error, unexpected ')' C:\wamp64\www\ci_role_permissions\application\controllers\admin\Users.php 96
ERROR - 2019-07-02 10:59:20 --> 404 Page Not Found: admin/Users/user_add
ERROR - 2019-07-02 11:01:53 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 11:02:04 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-02 11:26:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 11:26:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 11:26:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 11:26:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 11:26:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-02 11:26:21 --> 404 Page Not Found: Public/plugins
